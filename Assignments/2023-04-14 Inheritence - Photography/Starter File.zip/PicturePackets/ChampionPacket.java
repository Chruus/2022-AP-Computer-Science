public class ChampionPacket
{
	
}