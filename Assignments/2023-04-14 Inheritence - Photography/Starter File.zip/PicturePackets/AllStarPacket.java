public class AllStarPacket
{
   	
}