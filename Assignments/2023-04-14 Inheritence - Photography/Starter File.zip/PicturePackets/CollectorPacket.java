public class CollectorPacket 
{
	
}